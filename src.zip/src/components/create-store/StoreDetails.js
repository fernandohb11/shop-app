import React, { Component } from 'react'

export class StoreDetails extends Component {
  render() {
    return (
      <div>
        <h1>Hola desde tienda de detalles</h1>
      </div>
    )
  }
}

export default StoreDetails
